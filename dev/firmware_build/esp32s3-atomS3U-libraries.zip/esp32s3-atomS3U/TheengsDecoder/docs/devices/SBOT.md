# SwitchBot Outdoor Meter

|Model Id|[W340001X](https://github.com/theengs/decoder/blob/development/src/devices/SBOT_json.h)|
|-|-|
|Brand|SwitchBot|
|Model|Outdoor Meter|
|Short Description|Indoor/Outdoor Thermometer and Hygrometer|
|Communication|BLE broadcast|
|Frequency|2.4Ghz|
|Power Source|2 AAA|
|Exchanged Data|temperature, humidity, battery|
|Encrypted|No|
