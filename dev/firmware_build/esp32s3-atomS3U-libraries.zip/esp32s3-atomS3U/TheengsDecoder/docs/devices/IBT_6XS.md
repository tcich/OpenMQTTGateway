# Inkbird 6X(S) BBQ

|Model Id|[IBT_6X(S)](https://github.com/theengs/decoder/blob/development/src/devices/IBT_6XS_SOLIS6_json.h)|
|-|-|
|Brand|Inkbird|
|Model|BBQ Temperature sensor|
|Short Description|BBQ Temperature sensor with 6 probes|
|Communication|BLE broadcast|
|Frequency|2.4Ghz|
|Power Source|2 AAA (Rechargeable battery, USB)|
|Exchanged Data|temperature, temperature2, temperature3, temperature4, temperature5, temperature6|
|Encrypted|No|
