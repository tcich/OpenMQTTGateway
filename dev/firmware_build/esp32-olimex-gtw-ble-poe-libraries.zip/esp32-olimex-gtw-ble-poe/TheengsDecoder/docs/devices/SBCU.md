# SwitchBot Curtain

|Model Id|[W070160X](https://github.com/theengs/decoder/blob/development/src/devices/SBCU_json.h)|
|-|-|
|Brand|SwitchBot|
|Model|Curtain (2/3)|
|Short Description|Curtain motor|
|Communication|BLE broadcast|
|Frequency|2.4Ghz|
|Power Source|Rechargeable battery|
|Exchanged Data|moving, position, light level, battery, calibration state|
|Encrypted|No|
