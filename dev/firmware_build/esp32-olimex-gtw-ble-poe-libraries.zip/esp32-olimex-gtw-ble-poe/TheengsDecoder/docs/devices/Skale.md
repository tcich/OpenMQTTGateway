# Atomax Skale I/II

|Model Id|[SKALE](https://github.com/theengs/decoder/blob/development/src/devices/Skale_json.h)|
|-|-|
|Brand|Atomax|
|Model|Skale I/II|
|Short Description|Bluetooth kitchen scale|
|Communication|BLE broadcast|
|Frequency|2.4Ghz|
|Power Source|USB/4 AAA|
|Exchanged Data|weight|
|Encrypted|No|
