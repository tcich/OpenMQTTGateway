# Inkbird P01B

|Model Id|[IBS-P01B](https://github.com/theengs/decoder/blob/development/src/devices/IBS_THBP01B_json.h)|
|-|-|
|Brand|Inkbird|
|Model|Pool Thermometer|
|Short Description|Pool temperature sensor IPX7|
|Communication|BLE broadcast|
|Frequency|2.4Ghz|
|Power Source|2 AA|
|Exchanged Data|temperature, battery|
|Encrypted|No|
