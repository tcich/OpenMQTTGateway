const char* ss_client_key PROGMEM = R"EOF("
-----BEGIN RSA PRIVATE KEY-----
...
-----END RSA PRIVATE KEY-----
")EOF";
