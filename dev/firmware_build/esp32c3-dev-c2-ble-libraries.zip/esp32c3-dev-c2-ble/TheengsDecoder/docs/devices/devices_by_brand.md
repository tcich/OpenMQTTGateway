---
redirect: ./devices.html
---

# Redirecting...

If you are not redirected automatically, follow this <a href='https://decoder.theengs.io/devices/devices.html'>link to the compatible BT devices listing</a>.

<meta http-equiv="refresh" content="0; url=./devices.html">
<script type="text/javascript">
    window.location.href = "https://decoder.theengs.io/devices/devices.html"
</script>
