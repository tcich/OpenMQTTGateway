# Xiaomi Mi Smart Scale

|Model Id|[XMTZC01HM/XMTZC04HM](https://github.com/theengs/decoder/blob/development/src/devices/XMTZC04HM_json.h)|
|-|-|
|Brand|Xiaomi|
|Model|Mi Smart Scale|
|Short Description|First (MI_SCALE) and second (MI SCALE2) version of the Mi Smart Scale|
|Communication|BLE broadcast|
|Frequency|2.4Ghz|
|Power Source|4 AA/3 AAA|
|Exchanged Data|weighing_mode, unit, weight|
|Encrypted|No|
