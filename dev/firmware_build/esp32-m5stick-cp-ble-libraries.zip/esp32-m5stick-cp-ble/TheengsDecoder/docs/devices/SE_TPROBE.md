# Sensor Easy Thermometer External Probe Pro

|Model Id|[SE_TPROBE](https://github.com/theengs/decoder/blob/development/src/devices/SE_TPROBE_json.h)|
|-|-|
|Brand|Sensor Easy|
|Model|Sensor Easy Temperature External Probe Pro|
|Short Description|Indoor/Outdoor Thermometer|
|Communication|BLE broadcast|
|Frequency|2.4Ghz|
|Power Source|embedded|
|Exchanged Data|temperature, battery, volt|
|Encrypted|No|
