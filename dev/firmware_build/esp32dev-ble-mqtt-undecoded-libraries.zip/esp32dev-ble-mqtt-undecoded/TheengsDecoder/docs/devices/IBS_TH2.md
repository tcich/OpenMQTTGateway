# Inkbird TH2

|Model Id|[IBS-TH2](https://github.com/theengs/decoder/blob/development/src/devices/IBS_THBP01B_json.h)|
|-|-|
|Brand|Inkbird|
|Model|Thermometer Hygrometer|
|Short Description|Temperature and humidity (not for all models) sensor (also Plus model with external probe)|
|Communication|BLE broadcast|
|Frequency|2.4Ghz|
|Power Source|2 AAA/AA|
|Exchanged Data|temperature, humidity, battery|
|Encrypted|No|
|Image|![IBS-TH2](./../img/IBS-TH2.png)|
