# Jaalee TH sensor F525

|Model Id|[F525](https://github.com/theengs/decoder/blob/development/src/devices/JHT_F525_json.h)|
|-|-|
|Brand|Jaalee|
|Model|TH sensor|
|Short Description|Temperature and humidity sensor|
|Communication|BLE broadcast|
|Frequency|2.4Ghz|
|Power Source|CR2477|
|Exchanged Data|temperature, humidity, battery|
|Encrypted|No|
