#ifndef __DEV_CFG_H__
#define __DEV_CFG_H__

#define MK114

#endif
