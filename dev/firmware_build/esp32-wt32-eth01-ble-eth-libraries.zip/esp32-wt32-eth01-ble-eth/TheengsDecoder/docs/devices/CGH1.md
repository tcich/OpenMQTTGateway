# Qingping Contact Sensor CGH1

|Model Id|[CGH1](https://github.com/theengs/decoder/blob/development/src/devices/CGH1_json.h)|
|-|-|
|Brand|Qingping|
|Model|Contact sensor|
|Short Description|Door/Window contact sensor with Open-Close status|
|Communication|BLE broadcast|
|Frequency|2.4Ghz|
|Power Source|CR1632|
|Exchanged Data|open|
|Encrypted|No|
|Image|![CGH1](./../img/CGH1.png)|
