# Sensor Easy Thermometer

|Model Id|[SE_TEMP](https://github.com/theengs/decoder/blob/development/src/devices/SE_TEMP_json.h)|
|-|-|
|Brand|Sensor Easy|
|Model|Sensor Easy Temperature|
|Short Description|Indoor/Outdoor Thermometer|
|Communication|BLE broadcast|
|Frequency|2.4Ghz|
|Power Source|embedded|
|Exchanged Data|temperature, battery, volt|
|Encrypted|No|
