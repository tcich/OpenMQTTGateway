# Sensor Easy Door/Window sensor

|Model Id|[SE_MAG](https://github.com/theengs/decoder/blob/development/src/devices/SE_MAG_json.h)|
|-|-|
|Brand|Sensor Easy|
|Model|Sensor Easy Door/Window Pro|
|Short Description|Indoor/Outdoor Magnetic sensor|
|Communication|BLE broadcast|
|Frequency|2.4Ghz|
|Power Source|embedded|
|Exchanged Data|open, battery, volt|
|Encrypted|No|
