# Xiaomi Motion sensor and light

|Model Id|[MUE4094RT](https://github.com/theengs/decoder/blob/development/src/devices/MUE4094RT_json.h)|
|-|-|
|Brand|Xiaomi|
|Model|Motion and Light|
|Short Description|Motion sensor and ambient light|
|Communication|BLE broadcast|
|Frequency|2.4Ghz|
|Power Source|AA|
|Exchanged Data|darkness, motion|
|Encrypted|No|
