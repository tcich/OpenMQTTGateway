# BM6 Battery Monitor

|Model Id|[BM6](https://github.com/theengs/decoder/blob/development/src/devices/BM6_json.h)|
|-|-|
|Brand|GENERIC|
|Model|BM6 Battery Monitor|
|Short Description|Battery capacity|
|Communication|BLE broadcast|
|Frequency|2.4Ghz|
|Power Source|6V-20V|
|Exchanged Data|battery|
|Encrypted|No|
|Presence Tracker|&#9989;|
