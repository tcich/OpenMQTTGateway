# Scan and decode demo

## Requirements
- bleak: `pip install bleak`
- TheengsDecoder: (not available on PyPy yet) see the README in REPO_FOLDER/python for installation.
