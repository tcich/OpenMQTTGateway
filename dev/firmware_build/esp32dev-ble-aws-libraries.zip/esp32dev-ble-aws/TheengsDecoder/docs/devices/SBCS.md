# SwitchBot Contact Sensor

|Model Id|[W120150X](https://github.com/theengs/decoder/blob/development/src/devices/SBCS_json.h)|
|-|-|
|Brand|SwitchBot|
|Model|Contact Sensor|
|Short Description|Contact sensor|
|Communication|BLE broadcast|
|Frequency|2.4Ghz|
|Power Source|2 AAA|
|Exchanged Data|contact, motion, light level, scope tested, in count, out count, push count, battery|
|Encrypted|No|
