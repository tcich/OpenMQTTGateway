# Sensirion SHT4X Smart Gadget

|Model Id|[SHT4X](https://github.com/theengs/decoder/blob/development/src/devices/SHT4X_json.h)|
|-|-|
|Brand|Sensirion|
|Model|TH Sensor|
|Short Description|Temperature and humidity sensor|
|Communication|BLE broadcast|
|Frequency|2.4Ghz|
|Power Source|CR2032|
|Exchanged Data|temperature, humidity|
|Encrypted|No|
