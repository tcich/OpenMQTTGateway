# Xiaomi Formaldehyde detector

|Model Id|[JQJCY01YM](https://github.com/theengs/decoder/blob/development/src/devices/JQJCY01YM_json.h)|
|-|-|
|Brand|Xiaomi|
|Model|Formaldehyde detector|
|Short Description|Honeywell formaldehyde monitor|
|Communication|BLE broadcast|
|Frequency|2.4Ghz|
|Power Source|2 AA|
|Exchanged Data|formaldehyde, temperature, humidity, battery|
|Encrypted|No|
|Image|![JQJCY01YM](./../img/JQJCY01YM.png)|
