# Service data

|Model Id|[ServiceData](https://github.com/theengs/decoder/blob/development/src/devices/ServiceData_json.h)|
|-|-|
|Brand|GENERIC|
|Model|Service data|
|Short Description|Various devices broadcasting service data for Bluetooth SIG service UUIDs|
|Communication|BLE broadcast|
|Frequency|2.4Ghz|
|Power Source|various|
|Exchanged Data|battery|
|Encrypted|No|
