# Xiaomi RoPot

|Model Id|[HHCCPOT002](https://github.com/theengs/decoder/blob/development/src/devices/HHCCPOT002_json.h)|
|-|-|
|Brand|Xiaomi|
|Model|RoPot|
|Short Description|Moisture, temperature and fertility sensor|
|Communication|BLE broadcast|
|Frequency|2.4Ghz|
|Power Source|Rechargeable battery, USB|
|Exchanged Data|moisture, fertility|
|Encrypted|No|
