# Mopeka/Lippert Pro Check (Universal)/BottleCheck Sensor

|Model Id|[M1017](https://github.com/theengs/decoder/blob/development/src/devices/Mopeka_json.h)|
|-|-|
|Brand|Mopeka/Lippert|
|Model|Pro Check (Universal)/BottleCheck Sensor|
|Short Description|Ultrasonic LPG Tank level sensor|
|Communication|BLE broadcast|
|Frequency|2.4Ghz|
|Power Source|CR2032|
|Exchanged Data|temperature, level, sync status, voltage, battery, reading quality, acceleration x/y-axis|
|Encrypted|No|
|Image|![M1017](./../img/M1017.png)|
