# SwitchBot Bot

|Model Id|[X1](https://github.com/theengs/decoder/blob/development/src/devices/SBS1_json.h)|
|-|-|
|Brand|SwitchBot|
|Model|Bot|
|Short Description|Switch Button Pusher|
|Communication|BLE broadcast|
|Frequency|2.4Ghz|
|Power Source|1 CR2|
|Exchanged Data|mode, state, battery|
|Encrypted|No|
