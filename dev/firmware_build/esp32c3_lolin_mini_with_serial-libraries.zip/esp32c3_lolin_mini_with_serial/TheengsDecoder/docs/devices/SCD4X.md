# Sensirion MyCO₂/CO₂ Gadget SCD4X

|Model Id|[SCD4X](https://github.com/theengs/decoder/blob/development/src/devices/SCD4X_json.h)|
|-|-|
|Brand|Sensirion|
|Model|MyCO₂/CO₂ Gadget|
|Short Description|Temperature, humidity and CO₂ sensor|
|Communication|BLE broadcast|
|Frequency|2.4Ghz|
|Power Source|USB|
|Exchanged Data|temperature, humidity, carbon dioxide|
|Encrypted|No|
