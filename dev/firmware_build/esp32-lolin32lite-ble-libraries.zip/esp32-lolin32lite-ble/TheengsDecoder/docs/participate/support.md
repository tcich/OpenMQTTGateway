# Supporting the project

If you like the project and/or used it please consider supporting it! It can be done in different ways:
* Helping others in the [community](https://github.com/theengs/decoder/discussions)
* [Contribute](development) to the [code](https://github.com/theengs/decoder) or the documentation,
* Buy devices, boards or parts from the [OpenMQTTGateway compatible web site](https://compatible.openmqttgateway.com), the devices and parts linked use affiliated links,
* Donate or sponsor the project [developers](https://github.com/theengs/decoder/graphs/contributors)
* Make a video or a blog article about what you have done with [TheengsDecoder](https://github.com/theengs/decoder) and share it.