# Xiaomi LYWSDCGQ

|Model Id|[LYWSDCGQ](https://github.com/theengs/decoder/blob/development/src/devices/LYWSDCGQ_json.h)|
|-|-|
|Brand|Xiaomi|
|Model|Mi Jia|
|Short Description|Round Temperature and humidity sensor|
|Communication|BLE broadcast|
|Frequency|2.4Ghz|
|Power Source|1 AAA|
|Exchanged Data|temperature, humidity, battery|
|Encrypted|No|
|Image|![LYWSDCGQ](./../img/LYWSDCGQ.png)|
