# Sensor Easy Thermometer and Hygrometer Pro

|Model Id|[SE_RHT](https://github.com/theengs/decoder/blob/development/src/devices/SE_RHT_json.h)|
|-|-|
|Brand|Sensor Easy|
|Model|Sensor Easy Temperature and Humidity Pro|
|Short Description|Indoor/Outdoor Thermometer|
|Communication|BLE broadcast|
|Frequency|2.4Ghz|
|Power Source|embedded|
|Exchanged Data|temperature, humidity, battery, volt|
|Encrypted|No|
