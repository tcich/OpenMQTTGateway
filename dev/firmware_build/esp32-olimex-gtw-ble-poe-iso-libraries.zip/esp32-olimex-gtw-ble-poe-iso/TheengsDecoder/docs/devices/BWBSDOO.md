# Otio/BeeWi Smart Door & Window Sensor

|Model Id|[BSDOO](https://github.com/theengs/decoder/blob/development/src/devices/BWBSDOO_json.h)|
|-|-|
|Brand|Otio/BeeWi|
|Model|Door & Window Sensor|
|Short Description|Contact sensor|
|Communication|BLE broadcast|
|Frequency|2.4Ghz|
|Power Source|CR2032|
|Exchanged Data|open, battery|
|Encrypted|No|
