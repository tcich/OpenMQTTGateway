// Go won't use the C++ linker unless it detects at least one cpp file
// This file serves no other purpose