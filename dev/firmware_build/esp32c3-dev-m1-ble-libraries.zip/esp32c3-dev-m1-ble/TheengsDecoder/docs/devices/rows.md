# Rows

|Model Id|
|-|
|Image|
|Brand|
|Model|
|Short Description|
|Communication|
|Frequency|
|Power Source|
|Exchanged Data|
|Encrypted|
|Presence Tracker|
|Filename|
