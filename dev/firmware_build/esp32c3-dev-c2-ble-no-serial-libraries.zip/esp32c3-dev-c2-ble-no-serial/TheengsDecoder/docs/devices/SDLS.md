# SmartDry Laundry Sensor

|Model Id|[SDLS](https://github.com/theengs/decoder/blob/development/src/devices/SmartDry_json.h)|
|-|-|
|Brand|SmartDry|
|Model|Laundry Sensor|
|Short Description|Wireless Laundry Sensor|
|Communication|BLE broadcast|
|Frequency|2.4Ghz|
|Power Source|CR2032|
|Exchanged Data|temperature, humidity, shake, voltage, wake|
|Encrypted|No|
